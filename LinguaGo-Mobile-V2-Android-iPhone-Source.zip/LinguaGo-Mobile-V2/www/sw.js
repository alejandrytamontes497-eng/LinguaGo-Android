const CACHE='linguago-mobile-v2.5';
const FILES=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png','./bundled-library.js','./offline-audio-map.js'];
self.addEventListener('install', e => e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)).then(() => self.skipWaiting())));
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET' || new URL(e.request.url).origin !== self.location.origin) return;
  e.respondWith(caches.match(e.request).then(hit => hit || fetch(e.request).then(response => {let copy=response.clone();caches.open(CACHE).then(c => c.put(e.request, copy));return response;})));
});
