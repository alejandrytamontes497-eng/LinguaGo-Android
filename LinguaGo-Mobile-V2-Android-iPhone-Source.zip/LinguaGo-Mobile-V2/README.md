# LinguaGo V2 · 可构建 Android / iPhone App 的完整源代码

**当前交付：** 已把第一版网页原型整理为 **Capacitor 8 双平台构建项目**。可以通过 GitHub Actions 生成 Android **debug APK**，或在有 Android Studio 的电脑上本地构建；在 macOS 的 Xcode 中安装到 iPhone。**压缩包本身不是 APK/IPA，未实际在手机上签名、构建或实机验证。**

> 重要区别：`www/` 是可运行的网页 App；`package.json` + `capacitor.config.json` + `assets/` 等为原生打包准备。首次执行 `npx cap add ...` 时才生成 `android/` / `ios/` 原生工程，因为这里无法访问 npm 仓库、没有 Android SDK，也没有 macOS/Xcode。

## 先试用

直接在 Chrome / Edge 打开 `www/index.html`，即可体验大部分功能。语音功能依设备和浏览器而定。

## 想得到 Android APK（建议，适合不写代码的人）

1. 把**本压缩包解压出来的目录里的全部文件和 `.github/` 文件夹**上传到你自己的 GitHub 仓库根目录。注意不要只上传 ZIP 文件。
2. 打开 GitHub 仓库的 **Actions** 页。若 GitHub 要求启用 Actions，先启用。
3. 选择工作流 **构建 LinguaGo Android APK**，点击 **Run workflow**；或者在 `main` / `master` 分支提交一次文件。
4. 成功后打开该次运行的 **Artifacts**，下载 `LinguaGo-Android-debug-APK` 并解压，会得到 `app-debug.apk`。
5. 把 APK 传到 Android 手机并安装；系统可能要求对这次安装来源允许安装。仅从你自己的可信仓库获取 APK。

GitHub Actions 构建依赖外网；本项目已写好工作流，但**尚未实际运行它**。Debug APK 仅用于个人测试，发布需独立签名、隐私声明与上架准备。

## 本地 Android 构建

需 Node.js 22+、Android Studio 2025.2.1+、Android SDK。

```bash
npm install
npx cap add android
npx capacitor-assets generate --android
npx cap sync android
cd android
./gradlew assembleDebug  # Windows: gradlew.bat assembleDebug
```

输出 `android/app/build/outputs/apk/debug/app-debug.apk`。若需要 Android Studio，运行 `npx cap open android`。

## iPhone 安装（必须有 Mac + Xcode）

需 Node.js 22+，macOS、Xcode 26+（以 Capacitor 8 当前要求为准），以及用于真机签名的 Apple 账号。

```bash
npm install
npx cap add ios
npx capacitor-assets generate --ios
npx cap sync ios
npx cap open ios
```

Xcode 打开工程后，在 **Signing & Capabilities** 中选择你的 Apple Team、设置唯一 Bundle Identifier，连接 iPhone，选择你的设备，然后点击 ▶ Run。设备可能需要开启 Developer Mode。直接分享给他人或 App Store 发布有额外签名/审核要求。**该包未包含可直接安装的 IPA**。

## 浏览器主屏幕安装（免原生编译）

把 `www/` 全部文件部署到 HTTPS 网站。Android Chrome 的浏览器菜单中选择安装应用 / 添加到主屏幕；iPhone 使用 Safari 的分享菜单选择添加到主屏幕。**直接本地打开 `index.html` 不能获得正式的 PWA 安装体验**。

## 功能与限制

- 12 个单词，翻卡和测验；4 个听力场景；4 个情景口语练习；本机学习记录。
- Android/iPhone 两端使用同一套离线课程页面，由本机原生容器加载；不需要额外的课程服务器。
- 当前发音使用 Web Speech，兼容性依原生 WebView 及设备而定；麦克风识别在部分原生 WebView 中**可能不可用**。保留键盘输入作为稳定替代。
- 口语反馈仍是规则模拟，**不是 AI**。没有登录、云同步、付费 API、后端。
- **不同安装方式（浏览器/Android/iPhone）的 localStorage 不同步**，升级 App 时尽量保持 appId 与原生配置不变。

### 项目结构

```text
www/           原始练习 App 和 PWA 所需文件
assets/        适配 Android/iOS 的 1024 图标及 2732 启动画面
capacitor.config.json    原生应用名字、ID 和入口
.github/workflows/build-android-apk.yml  云端生成 debug APK
scripts/       本地构建脚本
docs/          版本 1 界面参考图
```

想实现真正的原生语音评分、AI 对话、云端同步和正式上架，还需要在后续版本实现对应原生插件、服务、用户隐私政策及商店材料。

官方文档：https://capacitorjs.com/docs/getting-started
