import { Capacitor } from '@capacitor/core';
import { TextToSpeech } from '@capacitor-community/text-to-speech';
import { SpeechRecognition } from '@capgo/capacitor-speech-recognition';

const isNative = () => Capacitor.isNativePlatform();

async function speak(text, rate = 1) {
  if (!isNative()) throw new Error('NATIVE_REQUIRED');
  // 每次重新播放时停止上一段，避免叠音。
  try { await TextToSpeech.stop(); } catch (_) {}
  await TextToSpeech.speak({
    text: String(text), lang: 'en-US', rate: Number(rate) || 1,
    pitch: 1, volume: 1, queueStrategy: 0
  });
}

async function recognize() {
  if (!isNative()) throw new Error('NATIVE_REQUIRED');
  const status = await SpeechRecognition.available();
  if (!status?.available) throw new Error('NO_RECOGNIZER');

  let permission = await SpeechRecognition.checkPermissions();
  if (permission?.speechRecognition !== 'granted') {
    permission = await SpeechRecognition.requestPermissions();
  }
  if (permission?.speechRecognition !== 'granted') throw new Error('MIC_PERMISSION_DENIED');

  // Android 原生识别对话框，返回英文文字。识别能力取决于设备支持。
  const result = await SpeechRecognition.start({
    language: 'en-US', maxResults: 1,
    popup: true, partialResults: false,
    prompt: '请说一段英语'
  });
  const transcript = result?.matches?.[0]?.trim() || '';
  if (!transcript) throw new Error('NO_MATCH');
  return transcript;
}

window.LinguaGoVoice = {isNative,speak,recognize};
