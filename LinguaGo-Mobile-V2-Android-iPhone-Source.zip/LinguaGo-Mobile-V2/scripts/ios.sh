#!/usr/bin/env bash
set -euo pipefail
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "iOS 真机编译需要 macOS、Xcode 和 Apple 签名配置。" >&2
  exit 1
fi
npm install
if [ ! -d ios ]; then npx cap add ios; fi
npx capacitor-assets generate --ios
npx cap sync ios
npx cap open ios
printf '%s\n' '在 Xcode 中选设备、在 Signing & Capabilities 中选择 Team，再点 Run 安装到手机。'
